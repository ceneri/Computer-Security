#!/bin/bash

#testing
python automation.py $1 $2 $3 $4 $5