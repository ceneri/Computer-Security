#!/bin/bash

#this file is currently used to test functionality
python decipherCaesar.py cipherMessage1 cipherMessage1 cipherMessage1
python decipherChainRot.py cipherMessage2 cipherMessage2 cipherMessage2
echo done
