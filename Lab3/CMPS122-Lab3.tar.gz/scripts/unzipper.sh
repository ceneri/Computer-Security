#!/bin/bash


unzip -P $1 $2
